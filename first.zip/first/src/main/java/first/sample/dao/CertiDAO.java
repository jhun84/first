package first.sample.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import first.common.dao.AbstractDAO;

@Repository("certiDAO")
public class CertiDAO extends AbstractDAO{

	@SuppressWarnings("unchecked")
	public Map<String, Object> certiBoardList(Map<String, Object> map) throws Exception{
	    return (Map<String, Object>)selectPagingList("certi.certiBoardList", map);
	}
	@SuppressWarnings("unchecked")
	public Map<String, Object> certiBoardSearch(Map<String, Object> map) throws Exception{
	    return (Map<String, Object>)selectPagingList("certi.certiBoardSearch", map);
	}
	public void insertCerti_company(Map<String, Object> map) throws Exception{
	    insert("certi.insertCerti_company", map);
	}
	@SuppressWarnings("unchecked")
	public Map<String, Object> selectCertiDetail(Map<String, Object> map) throws Exception{
	    return (Map<String, Object>) selectOne("certi.selectCertiDetail", map);
	}
	public void updateCerti_company(Map<String, Object> map) throws Exception{
	    update("certi.updateCerti_company", map);
	}
	public void deleteCerti_company(Map<String, Object> map) throws Exception{
	    update("certi.deleteCerti_company", map);
	}
	public void insertFile(Map<String, Object> map) throws Exception{
	    insert("certi.insertFile", map);
	}
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectFileList(Map<String, Object> map) throws Exception{
	    return (List<Map<String, Object>>)selectList("product.selectFileList", map);
	}
	public void deleteFileList(Map<String, Object> map) throws Exception{
	    update("certi.deleteFileList", map);
	}
	 
	public void updateFile(Map<String, Object> map) throws Exception{
	    update("certi.updateFile", map);
	}
	@SuppressWarnings("unchecked")
	public Map<String, Object> selectCooperList(Map<String, Object> map) throws Exception{
	    return (Map<String, Object>)selectPagingList("certi.selectCertiList", map);
	}
	public void insertCerti_money(Map<String, Object> map) throws Exception{
	    insert("certi.insertCerti_money", map);
	}
	public void updateCerti_money(Map<String, Object> map) throws Exception{
	    update("certi.updateCerti_money", map);
	}
	public void deleteCerti_money(Map<String, Object> map) throws Exception{
	    update("certi.deleteCerti_money", map);
	}
	public void insertCerti_people(Map<String, Object> map) throws Exception{
	    insert("certi.insertCerti_people", map);
	}
	public void updateCerti_people(Map<String, Object> map) throws Exception{
	    update("certi.updateCerti_people", map);
	}
	public void deleteCerti_people(Map<String, Object> map) throws Exception{
	    update("certi.deleteCerti_money", map);
	}

}
